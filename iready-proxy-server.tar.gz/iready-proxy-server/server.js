const express = require('express');
const { createProxyMiddleware } = require('http-proxy-middleware');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Enable CORS for all origins
app.use(cors({
  origin: true,
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS', 'PATCH'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'Accept', 'Origin']
}));

app.use(cookieParser());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files (the frontend)
app.use(express.static(path.join(__dirname, 'public')));

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Proxy middleware configuration
const createProxy = (target, pathRewrite = {}) => {
  return createProxyMiddleware({
    target: target,
    changeOrigin: true,
    secure: false,
    followRedirects: true,
    logLevel: 'debug',
    pathRewrite: pathRewrite,
    onProxyReq: (proxyReq, req, res) => {
      // Modify headers to appear as desktop browser
      proxyReq.setHeader('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36');
      proxyReq.setHeader('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8');
      proxyReq.setHeader('Accept-Language', 'en-US,en;q=0.9');
      proxyReq.setHeader('Accept-Encoding', 'gzip, deflate, br');
      proxyReq.setHeader('DNT', '1');
      proxyReq.setHeader('Connection', 'keep-alive');
      proxyReq.setHeader('Upgrade-Insecure-Requests', '1');
      proxyReq.setHeader('Sec-Fetch-Dest', 'document');
      proxyReq.setHeader('Sec-Fetch-Mode', 'navigate');
      proxyReq.setHeader('Sec-Fetch-Site', 'none');
      proxyReq.setHeader('Sec-Fetch-User', '?1');
      proxyReq.setHeader('sec-ch-ua', '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"');
      proxyReq.setHeader('sec-ch-ua-mobile', '?0');
      proxyReq.setHeader('sec-ch-ua-platform', '"Windows"');
      
      // Remove X-Frame-Options and other blocking headers
      proxyReq.removeHeader('X-Frame-Options');
      
      console.log(`[Proxy] ${req.method} ${req.url} -> ${target}${proxyReq.path}`);
    },
    onProxyRes: (proxyRes, req, res) => {
      // Remove security headers that block embedding
      delete proxyRes.headers['x-frame-options'];
      delete proxyRes.headers['content-security-policy'];
      delete proxyRes.headers['content-security-policy-report-only'];
      
      // Allow cross-origin access
      proxyRes.headers['Access-Control-Allow-Origin'] = '*';
      proxyRes.headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, DELETE, OPTIONS, PATCH';
      proxyRes.headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization, X-Requested-With';
      proxyRes.headers['Access-Control-Allow-Credentials'] = 'true';
      
      // Modify Set-Cookie to work with proxy
      if (proxyRes.headers['set-cookie']) {
        proxyRes.headers['set-cookie'] = proxyRes.headers['set-cookie'].map(cookie => {
          return cookie
            .replace(/;\s*Secure/gi, '')
            .replace(/;\s*SameSite=[^;]+/gi, '; SameSite=None')
            .replace(/Domain=[^;]+;?/gi, '');
        });
      }
      
      console.log(`[Proxy Response] ${proxyRes.statusCode} ${req.url}`);
    },
    onError: (err, req, res) => {
      console.error('[Proxy Error]', err.message);
      res.status(500).json({ 
        error: 'Proxy Error', 
        message: err.message,
        url: req.url 
      });
    }
  });
};

// i-Ready Proxy Routes
app.use('/proxy/iready', createProxy('https://login.i-ready.com', {
  '^/proxy/iready': ''
}));

app.use('/proxy/iready-www', createProxy('https://www.i-ready.com', {
  '^/proxy/iready-www': ''
}));

app.use('/proxy/cdn', createProxy('https://cdn.i-ready.com', {
  '^/proxy/cdn': ''
}));

// ClassLink Proxy Routes
app.use('/proxy/classlink', createProxy('https://launchpad.classlink.com', {
  '^/proxy/classlink': ''
}));

app.use('/proxy/classlink-sso', createProxy('https://sso.classlink.com', {
  '^/proxy/classlink-sso': ''
}));

// Generic proxy endpoint for any URL
app.get('/proxy', async (req, res) => {
  const targetUrl = req.query.url;
  
  if (!targetUrl) {
    return res.status(400).json({ error: 'URL parameter required' });
  }
  
  try {
    const fetch = (await import('node-fetch')).default;
    
    const response = await fetch(targetUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
        'Accept-Encoding': 'gzip, deflate, br',
        'DNT': '1',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'none',
        'Sec-Fetch-User': '?1',
        'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"'
      },
      redirect: 'follow'
    });
    
    const contentType = response.headers.get('content-type');
    
    // Set CORS headers
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    
    if (contentType && contentType.includes('text/html')) {
      let html = await response.text();
      
      // Rewrite URLs in the HTML to go through our proxy
      html = html.replace(/(href|src|action)=['"](https?:\/\/[^'"]+)['"]/gi, 
        (match, attr, url) => `${attr}="/proxy?url=${encodeURIComponent(url)}"`);
      
      // Remove frame-busting scripts
      html = html.replace(/<script[^>]*>[\s\S]*?top\s*!==\s*self[\s\S]*?<\/script>/gi, '');
      html = html.replace(/<script[^>]*>[\s\S]*?parent\s*!==\s*window[\s\S]*?<\/script>/gi, '');
      
      res.setHeader('Content-Type', 'text/html');
      res.send(html);
    } else {
      // For non-HTML content, pipe through
      response.body.pipe(res);
    }
    
  } catch (error) {
    console.error('[Proxy Fetch Error]', error);
    res.status(500).json({ error: 'Failed to fetch URL', message: error.message });
  }
});

// Fallback to serve index.html for any other route
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`
╔══════════════════════════════════════════════════════════╗
║           i-Ready Proxy Server Running!                  ║
╠══════════════════════════════════════════════════════════╣
║  Port: ${PORT}                                            ║
║  Health Check: http://localhost:${PORT}/health            ║
║                                                          ║
║  Proxy Endpoints:                                        ║
║  • /proxy/iready      → https://login.i-ready.com       ║
║  • /proxy/iready-www  → https://www.i-ready.com         ║
║  • /proxy/classlink   → https://launchpad.classlink.com ║
║  • /proxy?url=XXX     → Generic proxy                   ║
╚══════════════════════════════════════════════════════════╝
  `);
});
