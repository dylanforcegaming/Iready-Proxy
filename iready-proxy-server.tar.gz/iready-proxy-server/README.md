# i-Ready Mobile Proxy Server

A computer proxy server that routes i-Ready traffic, making it accessible on mobile devices by presenting desktop browser headers.

## How It Works

1. **Your Phone** → connects to **Proxy Server**
2. **Proxy Server** → fetches i-Ready with **desktop User-Agent**
3. **i-Ready** → sees a desktop computer → **allows access**
4. **Proxy Server** → returns content to **Your Phone**

## Free Hosting Options

### Option 1: Render (Recommended - Free Forever)

1. Go to [render.com](https://render.com) and sign up
2. Click **"New +"** → **"Web Service"**
3. Connect your GitHub or use "Upload Code"
4. Configure:
   - **Name:** `iready-proxy`
   - **Runtime:** Node
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
5. Click **"Create Web Service"**
6. Wait for deployment (~2 minutes)
7. Your URL will be: `https://iready-proxy.onrender.com`

### Option 2: Railway (Free Tier)

1. Go to [railway.app](https://railway.app) and sign up
2. Click **"New Project"** → **"Deploy from GitHub repo"**
3. Select your repository or upload code
4. Railway auto-detects Node.js and deploys
5. Your URL will be provided after deployment

### Option 3: Glitch (Free, Always On)

1. Go to [glitch.com](https://glitch.com)
2. Click **"New Project"** → **"Import from GitHub"**
3. Or manually upload the files
4. The project auto-runs
5. Your URL: `https://your-project-name.glitch.me`

### Option 4: Replit (Free)

1. Go to [replit.com](https://replit.com)
2. Create new Node.js repl
3. Upload all files
4. Click **"Run"**
5. Your URL will be provided

## Project Structure

```
iready-proxy-server/
├── package.json      # Dependencies
├── server.js         # Proxy server code
├── README.md         # This file
└── public/
    └── index.html    # Frontend interface
```

## Local Testing

```bash
# Install dependencies
npm install

# Start server
npm start

# Open http://localhost:3000
```

## Proxy Endpoints

| Endpoint | Description |
|----------|-------------|
| `/proxy/iready` | i-Ready Login |
| `/proxy/classlink` | ClassLink SSO |
| `/proxy/iready-www` | i-Ready Dashboard |
| `/proxy?url=XXX` | Generic proxy for any URL |

## Features

- ✅ Spoofs desktop User-Agent
- ✅ Removes X-Frame-Options headers
- ✅ Handles cookies properly
- ✅ Mobile/Desktop view modes
- ✅ CORS enabled
- ✅ Session persistence

## Troubleshooting

**"Cannot connect to server"**
- Check if the server is running
- Verify the URL is correct

**"Still shows mobile blocked"**
- Clear browser cookies
- Try incognito/private mode
- Use Desktop mode toggle

**"Session expires quickly"**
- Some schools have short session timeouts
- This is controlled by i-Ready, not the proxy

## Security Notes

- This proxy only modifies headers to appear as desktop
- It doesn't bypass authentication
- You still need valid i-Ready/ClassLink credentials
- All traffic goes through your hosted server

## Disclaimer

This tool is for educational accessibility purposes only. Users are responsible for complying with their school's acceptable use policy.
