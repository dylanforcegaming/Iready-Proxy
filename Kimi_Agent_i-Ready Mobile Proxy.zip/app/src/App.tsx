import { useState, useRef, useEffect } from 'react'
import './App.css'
import { 
  Smartphone, 
  Monitor, 
  RotateCw, 
  Menu,
  ChevronLeft,
  ChevronRight,
  Maximize2,
  Minimize2,
  ExternalLink
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription 
} from '@/components/ui/dialog'
import { 
  Sheet, 
  SheetContent, 
  SheetHeader, 
  SheetTitle, 
  SheetTrigger 
} from '@/components/ui/sheet'


type ViewMode = 'mobile' | 'desktop'
type Orientation = 'portrait' | 'landscape'

function App() {
  const [url, setUrl] = useState('')
  const [currentUrl, setCurrentUrl] = useState('')
  const [viewMode, setViewMode] = useState<ViewMode>('desktop')
  const [orientation, setOrientation] = useState<Orientation>('landscape')
  const [isLoading, setIsLoading] = useState(false)
  const [showLoginDialog, setShowLoginDialog] = useState(true)
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [history, setHistory] = useState<string[]>([])
  const [historyIndex, setHistoryIndex] = useState(-1)
  const iframeRef = useRef<HTMLIFrameElement>(null)

  // Common i-Ready and ClassLink URLs
  const quickLinks = [
    { name: 'i-Ready Login', url: 'https://login.i-ready.com' },
    { name: 'ClassLink', url: 'https://launchpad.classlink.com' },
    { name: 'i-Ready Dashboard', url: 'https://www.i-ready.com' },
  ]

  const handleNavigate = (targetUrl: string) => {
    if (!targetUrl) return
    
    let finalUrl = targetUrl
    if (!targetUrl.startsWith('http')) {
      finalUrl = 'https://' + targetUrl
    }
    
    setIsLoading(true)
    setCurrentUrl(finalUrl)
    
    // Add to history
    const newHistory = history.slice(0, historyIndex + 1)
    newHistory.push(finalUrl)
    setHistory(newHistory)
    setHistoryIndex(newHistory.length - 1)
    
    setTimeout(() => setIsLoading(false), 1500)
  }

  const handleBack = () => {
    if (historyIndex > 0) {
      setHistoryIndex(historyIndex - 1)
      setCurrentUrl(history[historyIndex - 1])
    }
  }

  const handleForward = () => {
    if (historyIndex < history.length - 1) {
      setHistoryIndex(historyIndex + 1)
      setCurrentUrl(history[historyIndex + 1])
    }
  }

  const handleRefresh = () => {
    if (iframeRef.current) {
      setIsLoading(true)
      iframeRef.current.src = iframeRef.current.src
      setTimeout(() => setIsLoading(false), 1000)
    }
  }

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen()
      setIsFullscreen(true)
    } else {
      document.exitFullscreen()
      setIsFullscreen(false)
    }
  }

  const getIframeWidth = () => {
    if (viewMode === 'mobile') {
      return orientation === 'portrait' ? '375px' : '667px'
    }
    return '100%'
  }

  const getIframeHeight = () => {
    if (viewMode === 'mobile') {
      return orientation === 'portrait' ? '667px' : '375px'
    }
    return '100%'
  }

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement)
    }
    document.addEventListener('fullscreenchange', handleFullscreenChange)
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange)
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex flex-col">
      {/* Header */}
      <header className="bg-black/30 backdrop-blur-md border-b border-white/10 px-4 py-3">
        <div className="flex items-center justify-between gap-4">
          {/* Logo & Title */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-green-400 to-emerald-600 rounded-xl flex items-center justify-center shadow-lg">
              <Smartphone className="w-5 h-5 text-white" />
            </div>
            <div className="hidden sm:block">
              <h1 className="text-white font-bold text-lg">i-Ready Mobile</h1>
              <p className="text-white/50 text-xs">Mobile-Friendly Proxy</p>
            </div>
          </div>

          {/* Navigation Controls */}
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={handleBack}
              disabled={historyIndex <= 0}
              className="text-white/70 hover:text-white hover:bg-white/10"
            >
              <ChevronLeft className="w-5 h-5" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleForward}
              disabled={historyIndex >= history.length - 1}
              className="text-white/70 hover:text-white hover:bg-white/10"
            >
              <ChevronRight className="w-5 h-5" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleRefresh}
              className="text-white/70 hover:text-white hover:bg-white/10"
            >
              <RotateCw className={`w-5 h-5 ${isLoading ? 'animate-spin' : ''}`} />
            </Button>
          </div>

          {/* View Mode Toggle */}
          <div className="flex items-center gap-2 bg-white/10 rounded-lg p-1">
            <Button
              variant={viewMode === 'mobile' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setViewMode('mobile')}
              className={viewMode === 'mobile' ? 'bg-green-500 hover:bg-green-600' : 'text-white/70 hover:text-white hover:bg-white/10'}
            >
              <Smartphone className="w-4 h-4 mr-1" />
              <span className="hidden sm:inline">Mobile</span>
            </Button>
            <Button
              variant={viewMode === 'desktop' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setViewMode('desktop')}
              className={viewMode === 'desktop' ? 'bg-blue-500 hover:bg-blue-600' : 'text-white/70 hover:text-white hover:bg-white/10'}
            >
              <Monitor className="w-4 h-4 mr-1" />
              <span className="hidden sm:inline">Desktop</span>
            </Button>
          </div>

          {/* Menu */}
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="text-white/70 hover:text-white hover:bg-white/10">
                <Menu className="w-5 h-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="bg-slate-900 border-white/10">
              <SheetHeader>
                <SheetTitle className="text-white">Quick Links</SheetTitle>
              </SheetHeader>
              <div className="mt-6 space-y-3">
                {quickLinks.map((link) => (
                  <Button
                    key={link.url}
                    variant="outline"
                    className="w-full justify-start text-white border-white/20 hover:bg-white/10"
                    onClick={() => handleNavigate(link.url)}
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    {link.name}
                  </Button>
                ))}
              </div>
              <div className="mt-8 pt-6 border-t border-white/10">
                <p className="text-white/50 text-sm mb-4">View Options</p>
                {viewMode === 'mobile' && (
                  <Button
                    variant="outline"
                    className="w-full text-white border-white/20 hover:bg-white/10"
                    onClick={() => setOrientation(orientation === 'portrait' ? 'landscape' : 'portrait')}
                  >
                    <RotateCw className="w-4 h-4 mr-2" />
                    Rotate Screen
                  </Button>
                )}
              </div>
            </SheetContent>
          </Sheet>
        </div>

        {/* URL Bar */}
        <div className="mt-3 flex gap-2">
          <div className="flex-1 relative">
            <input
              type="text"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleNavigate(url)}
              placeholder="Enter URL (e.g., login.i-ready.com)"
              className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-2 text-white placeholder:text-white/40 focus:outline-none focus:ring-2 focus:ring-green-500/50"
            />
          </div>
          <Button
            onClick={() => handleNavigate(url)}
            className="bg-green-500 hover:bg-green-600 text-white"
          >
            <ExternalLink className="w-4 h-4 mr-1" />
            Go
          </Button>
          <Button
            variant="outline"
            onClick={toggleFullscreen}
            className="text-white border-white/20 hover:bg-white/10"
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex items-center justify-center p-4 overflow-hidden">
        {currentUrl ? (
          <div 
            className={`relative bg-white rounded-xl overflow-hidden shadow-2xl transition-all duration-300 ${
              viewMode === 'mobile' ? 'border-8 border-slate-800 rounded-[2rem]' : 'w-full h-full'
            }`}
            style={{
              width: getIframeWidth(),
              height: getIframeHeight(),
              maxWidth: '100%',
              maxHeight: 'calc(100vh - 180px)'
            }}
          >
            {/* Mobile Frame Details */}
            {viewMode === 'mobile' && (
              <>
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-6 bg-slate-800 rounded-b-xl z-10" />
                <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-24 h-1 bg-slate-700 rounded-full z-10" />
              </>
            )}

            {/* Loading Overlay */}
            {isLoading && (
              <div className="absolute inset-0 bg-white z-20 flex flex-col items-center justify-center">
                <div className="w-12 h-12 border-4 border-green-500 border-t-transparent rounded-full animate-spin" />
                <p className="mt-4 text-slate-600 font-medium">Loading...</p>
              </div>
            )}

            {/* Iframe */}
            <iframe
              ref={iframeRef}
              src={currentUrl}
              className="w-full h-full border-0"
              sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-top-navigation"
              allow="fullscreen; camera; microphone; autoplay"
              title="i-Ready Proxy"
              style={{
                transform: viewMode === 'mobile' ? 'scale(1)' : 'none',
                transformOrigin: 'top left'
              }}
            />
          </div>
        ) : (
          <div className="text-center">
            <div className="w-24 h-24 bg-white/10 rounded-3xl flex items-center justify-center mx-auto mb-6">
              <Smartphone className="w-12 h-12 text-green-400" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-2">i-Ready Mobile Proxy</h2>
            <p className="text-white/60 mb-6 max-w-md">
              Access i-Ready on your mobile device with an optimized interface. 
              Enter a URL above or select a quick link to get started.
            </p>
            <div className="flex flex-wrap justify-center gap-3">
              {quickLinks.map((link) => (
                <Button
                  key={link.url}
                  onClick={() => handleNavigate(link.url)}
                  className="bg-white/10 hover:bg-white/20 text-white border border-white/20"
                >
                  {link.name}
                </Button>
              ))}
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-black/30 backdrop-blur-md border-t border-white/10 px-4 py-2">
        <div className="flex items-center justify-between text-white/40 text-sm">
          <div className="flex items-center gap-4">
            <span>Mode: <span className="text-green-400 capitalize">{viewMode}</span></span>
            {viewMode === 'mobile' && (
              <span>Orientation: <span className="text-blue-400 capitalize">{orientation}</span></span>
            )}
          </div>
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${currentUrl ? 'bg-green-500' : 'bg-yellow-500'}`} />
            <span>{currentUrl ? 'Connected' : 'Ready'}</span>
          </div>
        </div>
      </footer>

      {/* Initial Login Dialog */}
      <Dialog open={showLoginDialog} onOpenChange={setShowLoginDialog}>
        <DialogContent className="bg-slate-900 border-white/10 text-white max-w-md">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-green-400 to-emerald-600 rounded-lg flex items-center justify-center">
                <Smartphone className="w-4 h-4 text-white" />
              </div>
              Welcome to i-Ready Mobile
            </DialogTitle>
            <DialogDescription className="text-white/60">
              Access i-Ready on your mobile device with an optimized, touch-friendly interface.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 mt-4">
            <div className="bg-white/5 rounded-lg p-4">
              <h3 className="font-semibold text-white mb-2">Quick Start Options:</h3>
              <ul className="space-y-2 text-sm text-white/70">
                <li className="flex items-center gap-2">
                  <div className="w-5 h-5 bg-green-500/20 rounded flex items-center justify-center text-green-400 text-xs">1</div>
                  Click "i-Ready Login" to go directly to the login page
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-5 h-5 bg-blue-500/20 rounded flex items-center justify-center text-blue-400 text-xs">2</div>
                  Use ClassLink for SSO authentication
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-5 h-5 bg-purple-500/20 rounded flex items-center justify-center text-purple-400 text-xs">3</div>
                  Switch between Mobile and Desktop views
                </li>
              </ul>
            </div>

            <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-3">
              <p className="text-yellow-400 text-sm">
                <strong>Note:</strong> Some school networks may require you to be on their WiFi or use a VPN.
              </p>
            </div>

            <div className="flex gap-2">
              <Button
                onClick={() => {
                  handleNavigate('https://login.i-ready.com')
                  setShowLoginDialog(false)
                }}
                className="flex-1 bg-green-500 hover:bg-green-600 text-white"
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                i-Ready Login
              </Button>
              <Button
                onClick={() => {
                  handleNavigate('https://launchpad.classlink.com')
                  setShowLoginDialog(false)
                }}
                className="flex-1 bg-blue-500 hover:bg-blue-600 text-white"
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                ClassLink
              </Button>
            </div>
            
            <Button
              variant="ghost"
              onClick={() => setShowLoginDialog(false)}
              className="w-full text-white/60 hover:text-white"
            >
              I'll enter a URL manually
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}

export default App
